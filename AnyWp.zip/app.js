//website
if( wp_site = urlParams.site){
    wp(wp_site)
}else{
    indexPage()
}